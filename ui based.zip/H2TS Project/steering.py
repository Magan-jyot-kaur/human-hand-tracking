import math
import cv2
import mediapipe as mp
import mainui

def steer():
# Define a function to check if a point is within a rectangle
    def point_inside_rect(point, rect):
        x, y = point
        x1, y1, x2, y2 = rect
        return x1 <= x <= x2 and y1 <= y <= y2

    mp_drawing = mp.solutions.drawing_utils
    mp_hands = mp.solutions.hands
    font = cv2.FONT_HERSHEY_SIMPLEX
    cap = cv2.VideoCapture(0)

    with mp_hands.Hands(
            model_complexity=0,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5) as hands:
        while cap.isOpened():
            success, image = cap.read()
            if not success:
                print("Ignoring empty camera frame.")
                continue

            image_height, image_width, _ = image.shape
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = hands.process(image_rgb)

            # List to store coordinates of detected landmarks
            co = []

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    mp_drawing.draw_landmarks(
                        image,
                        hand_landmarks,
                        mp_hands.HAND_CONNECTIONS,
                        mp.solutions.drawing_styles.get_default_hand_landmarks_style(),
                        mp.solutions.drawing_styles.get_default_hand_connections_style())
                    for point in [mp_hands.HandLandmark.INDEX_FINGER_TIP, mp_hands.HandLandmark.MIDDLE_FINGER_TIP]:
                        normalized_landmark = hand_landmarks.landmark[point]
                        pixel_coordinates_landmark = mp_drawing._normalized_to_pixel_coordinates(normalized_landmark.x,
                                                                                            normalized_landmark.y,
                                                                                            image_width, image_height)
                        try:
                            co.append(list(pixel_coordinates_landmark))
                        except:
                            continue

            # Draw 'X' button
            cv2.rectangle(image, (10, 10), (50, 50), (0,0,255), -1)  # Draw a red rectangle
            cv2.putText(image, "X", (20, 40), font, 1, (255, 255, 255), 2, cv2.LINE_AA)  # Draw text 'X'

            # If both index and middle finger tips are detected
            if len(co) == 2:
                # Calculate the Euclidean distance between index and middle finger tips
                distance = math.sqrt((co[0][0] - co[1][0]) ** 2 + (co[0][1] - co[1][1]) ** 2)

                # Check if the distance is less than a threshold and if the fingers are within the 'X' button region
                if distance < 50 and point_inside_rect(co[0], (10, 10, 50, 50)) and point_inside_rect(co[1], (10, 10, 50, 50)):
                    # Close the application
                    cap.release()
                    cv2.destroyAllWindows()
                    mainui.ui()

            cv2.imshow('MediaPipe Hands', cv2.flip(image, 1))

            if cv2.waitKey(5) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

