import cv2
from handtrackingmodule_2 import HandDetector
import aivirtual_painter as vp
import aiVirtualMouse as vm
import aivolumecontroller as vc
import eye_gaze as eg
import HandTracking_Calc as cc
import steering as st
import sys

def draw_button_x(img):
    button_x_size = 50
    button_x_thickness = 2
    button_x_color = (255, 255, 255)  # White color for the button X
    background_color = (0, 0, 255)  # red color for the background
    # Draw the red background for the button X
    cv2.rectangle(img, (1280 - button_x_size, 0), (1280, button_x_size), background_color, cv2.FILLED)
    # Draw the X
    cv2.line(img, (1280 - button_x_size + 5, 5), (1280 - 5, button_x_size - 5), button_x_color, button_x_thickness)
    cv2.line(img, (1280 - button_x_size + 5, button_x_size - 5), (1280 - 5, 5), button_x_color, button_x_thickness)
    return (1280 - button_x_size, 0, 1280, button_x_size)  # Return the coordinates of the button X

# Define the Button class
class Button:
    def __init__(self, text, position, size):
        self.text = text
        self.position = position
        self.size = size

    def draw(self, img):
        x, y = self.position
        width, height = self.size
        height *= 2
        width *= 2
        cv2.rectangle(img, (x, y), (x + width, y + height), (255, 255, 255), -1)
        cv2.rectangle(img, (x, y), (x + width, y + height), (0, 0, 0), 2)
        text_size = cv2.getTextSize(self.text, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
        text_x = x + (width - text_size[0]) // 2
        text_y = y + (height + text_size[1]) // 2
        cv2.putText(img, self.text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
    
    def checkClick(self, x, y):
        if self.position[0] < x < self.position[0] + self.size[0] and \
                self.position[1] < y < self.position[1] + self.size[1]:
            cv2.rectangle(img, (self.position[0] + 3, self.position[1] + 3),
                        (self.position[0] + self.size[0] - 3, self.position[1] + self.size[1] - 3),
                        (255, 255, 255), cv2.FILLED)
            cv2.putText(img, self.text, (self.position[0] + 25, self.position[1] + 80), cv2.FONT_HERSHEY_PLAIN,
                        5, (0, 0, 0), 5)
            return True
        else:
            return False


# Webcam
cap = cv2.VideoCapture(0)
cap.set(3, 1280) # width
cap.set(4, 720) # height
detector = HandDetector(detectionCon=0.8, maxHands=1)

# Create buttons
buttonListValues = ["volume controller", "painter",
                     "virtual mouse", "eye control",
                     "calculator", "steering"]
buttons = []
for i, text in enumerate(buttonListValues):
    button = Button(text, (10, 10 + i * 80), (150, 60))  # Adjusted button creation
    buttons.append(button)

# Main loop
while True:
    # Get image frame
    success, img = cap.read()
    
    # checking if img returning none
    if not success:
        print('failed to read the cam')
        break

    img = cv2.flip(img, 1)
    
    # Find hands
    hands, img = detector.findHands(img, flipType=False)
    
    # Check if hands are detected
    if hands is not None:
        # Draw buttons
        for button in buttons:
            button.draw(img)

        button_clicked = None

        # Check for hand click
        if hands:
            # Find distance between fingers
            lmList = hands[0]['lmList']
            length, _, img = detector.findDistance(lmList[8], lmList[12], img)
            x, y = lmList[8]

            # Check if any button is clicked
            if length < 50:
                for button in buttons:
                    if button.checkClick(x, y):
                        button_clicked = button.text
                        # Perform action corresponding to the clicked button
                        if button_clicked:
                            if button_clicked == "volume controller":
                                print("Volume Controller clicked")
                                cap.release()
                                cv2.destroyAllWindows()
                                vc.volume()
                                sys.exit()

                            elif button_clicked == "painter":
                                print("Painter clicked")
                                cap.release()
                                cv2.destroyAllWindows() 
                                vp.painter()
                                sys.exit()

                            elif button_clicked == "virtual mouse":
                                print("Virtual Mouse clicked")
                                cap.release()
                                cv2.destroyAllWindows()
                                vm.mouse()
                                sys.exit()

                            elif button_clicked == "eye control":
                                print("Eye Control Clicked")
                                cap.release()
                                cv2.destroyAllWindows()
                                eg.gaze()
                                sys.exit()

                            elif button_clicked == "calculator":
                                print("Calculator Clicked")
                                cap.release()
                                cv2.destroyAllWindows()
                                cc.calc()
                                sys.exit()

                            elif button_clicked == "steering":
                                print("Steering Clicked")
                                cap.release()
                                cv2.destroyAllWindows()
                                st.steer()
                                sys.exit()

        # Check if the X button is clicked
        button_x_coords = draw_button_x(img)
        if hands:
            lmList = hands[0]['lmList']
            if lmList[8][0] > button_x_coords[0] and lmList[8][1] < button_x_coords[3]:
                print("Exiting Program")
                break

    # Display the image
    cv2.imshow("Image", img)

    # Exit when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close all windows
if cap.release() is None:
    print("Camera released successfully")
else:
    print("Failed to release camera")

cv2.destroyAllWindows()