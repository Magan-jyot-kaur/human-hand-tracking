import cv2
from handtrackingmodule_2 import HandDetector
import os

# Define actions for button clicks
def volume_controller_action():
    print("Volume Controller clicked")
    cap.release()
    cv2.destroyAllWindows()
    os.system('python aivolumecontroller.py')  

def painter_action():
    print("Painter clicked")
    cap.release()
    cv2.destroyAllWindows()    
    os.system('python aivirtual_painter.py')

def virtual_mouse_action():
    print("Virtual Mouse clicked")
    cap.release()
    cv2.destroyAllWindows()
    os.system('python aiVirtualMouse.py')

def eye_control_action():
    print("Eye Control Clicked")
    cap.release()
    cv2.destroyAllWindows()
    os.system('python eye_gaze.py')

def calculator_action():
    print("Calculator Clicked")
    cap.release()
    cv2.destroyAllWindows()
    os.system('python HandTracking_Calc.py')

def steering_action():
    print("Steering Clicked")
    cap.release()
    cv2.destroyAllWindows()
    os.system('python steering.py')

# Define the Button class
class Button:
    def __init__(self, text, position, size):
        self.text = text
        self.position = position
        self.size = size

    def draw(self, img):
        x, y = self.position
        width, height = self.size
        height *= 2
        width *= 2
        cv2.rectangle(img, (x, y), (x + width, y + height), (255, 255, 255), -1)
        cv2.rectangle(img, (x, y), (x + width, y + height), (0, 0, 0), 2)
        text_size = cv2.getTextSize(self.text, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
        text_x = x + (width - text_size[0]) // 2
        text_y = y + (height + text_size[1]) // 2
        cv2.putText(img, self.text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
    
    def checkClick(self, x, y):
        if self.position[0] < x < self.position[0] + self.size[0] and \
                self.position[1] < y < self.position[1] + self.size[1]:
            cv2.rectangle(img, (self.position[0] + 3, self.position[1] + 3),
                        (self.position[0] + self.size[0] - 3, self.position[1] + self.size[1] - 3),
                        (255, 255, 255), cv2.FILLED)
            cv2.putText(img, self.text, (self.position[0] + 25, self.position[1] + 80), cv2.FONT_HERSHEY_PLAIN,
                        5, (0, 0, 0), 5)
            return True
        else:
            return False


# Webcam
cap = cv2.VideoCapture(0)
cap.set(3, 1280) # width
cap.set(4, 720) # height
detector = HandDetector(detectionCon=0.8, maxHands=1)

# Create buttons
buttonListValues = ["volume controller", "painter",
                     "virtual mouse", "eye control",
                     "calculator", "steering"]
buttons = []
for i, text in enumerate(buttonListValues):
    button = Button(text, (10, 10 + i * 80), (150, 60))  # Adjusted button creation
    buttons.append(button)

# Main loop
while True:
    # Get image frame
    success, img = cap.read()
    img = cv2.flip(img, 1)
    hands, img = detector.findHands(img, flipType=False)
 
    # Draw buttons
    for button in buttons:
        button.draw(img)

    button_clicked = None

    # Check for Hand
    if hands:
        # Find distance between fingers
        lmList = hands[0]['lmList']
        length, _, img = detector.findDistance(lmList[8], lmList[12], img)
        print(length)
        x,y = lmList[8]

        # Check if any button is clicked
        if length<50:
            for button in buttons:
                if button.checkClick(x,y):
                    button_clicked = button.text
                    break

    # Perform action corresponding to the clicked button
    if button_clicked:
        if button_clicked == "volume controller":
            volume_controller_action()

        elif button_clicked == "painter":
            painter_action()

        elif button_clicked == "virtual mouse":
            virtual_mouse_action()

        elif button_clicked == "eye control":
            eye_control_action()

        elif button_clicked == "calculator":
            calculator_action()

        elif button_clicked == "steering":
            steering_action()

    # Display
    cv2.imshow("Image", img)

    # Exit when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam and close all windows
cap.release()
cv2.destroyAllWindows()
 