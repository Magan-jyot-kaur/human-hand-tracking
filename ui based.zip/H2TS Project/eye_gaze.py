import cv2
import mediapipe as mp
import pyautogui
import mainui

def gaze():

    def draw_button_x(img):
        button_x_size = 50
        button_x_thickness = 2
        button_x_color = (255, 255, 255)  # White color for the button X
        background_color = (0, 0, 255)  # Red color for the background
        # Draw the red background for the button X
        cv2.rectangle(img, (640 - button_x_size, 0), (640, button_x_size), background_color, cv2.FILLED)
        # Draw the X
        cv2.line(img, (640 - button_x_size + 5, 5), (640 - 5, button_x_size - 5), button_x_color, button_x_thickness)
        cv2.line(img, (640 - button_x_size + 5, button_x_size - 5), (640 - 5, 5), button_x_color, button_x_thickness)
        return (640 - button_x_size, 0, 640, button_x_size)  # Return the coordinates of the button X

    cam = cv2.VideoCapture(0)
    face_mesh = mp.solutions.face_mesh.FaceMesh(refine_landmarks=True)
    screen_w, screen_h = pyautogui.size()

    while True:

        _, frame = cam.read()
        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        output = face_mesh.process(rgb_frame)
        landmark_points = output.multi_face_landmarks
        frame_h, frame_w, _ = frame.shape

        # Draw X button
        button_x_coords = draw_button_x(frame)

        if landmark_points:
            landmarks = landmark_points[0].landmark

            for id, landmark in enumerate(landmarks[474:478]):
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                cv2.circle(frame, (x, y), 3, (0, 255, 0))

                if id == 1:
                    screen_x = screen_w * landmark.x
                    screen_y = screen_h * landmark.y
                    pyautogui.moveTo(screen_x, screen_y)

            left = [landmarks[145], landmarks[159]]

            # Calculate the vertical distance between two specific landmarks of the left eye
            eye_openness = landmarks[145].y - landmarks[159].y

            # Check if the X button is blinked over
            if eye_openness < 0.004 and button_x_coords:
                if button_x_coords[0] < landmarks[145].x * frame_w < button_x_coords[2] and button_x_coords[1] < landmarks[145].y * frame_h < button_x_coords[3]:
                    print("Exiting Program")
                    cam.release()
                    cv2.destroyAllWindows()
                    mainui.ui()

            for landmark in left:
                x = int(landmark.x * frame_w)
                y = int(landmark.y * frame_h)
                cv2.circle(frame, (x, y), 3, (0, 255, 255))

            if (left[0].y - left[1].y) < 0.004:
                pyautogui.click()
                print('click')

        cv2.imshow('Eye Controlled Mouse', frame)
        cv2.waitKey(1)
